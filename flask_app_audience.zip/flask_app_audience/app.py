from flask import Flask, request, render_template
from models.blip_model import generate_caption_and_story
import os

app = Flask(__name__)
UPLOAD_FOLDER = 'static/uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        image_file = request.files['image']
        audience = request.form.get('audience', 'general')
        if image_file:
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], image_file.filename)
            image_file.save(file_path)

            caption, artist, style, genre, story = generate_caption_and_story(file_path, image_file.filename, audience)

            return render_template('index.html',
                                   image_url=file_path,
                                   caption=caption,
                                   artist=artist,
                                   style=style,
                                   genre=genre,
                                   audience=audience,
                                   story=story)
    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)
